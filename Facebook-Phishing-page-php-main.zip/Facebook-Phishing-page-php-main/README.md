# Facebook-Phishing-page-php



![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FArchismanKarmakar%2FFacebook-Phishing-page-php&count_bg=%23FF8000&title_bg=%23000000&icon=&icon_color=%23E7E7E7&title=Visits&edge_flat=true)

## ⚠️⚠️ DISCLAIMER!!! ⚠️⚠️

Hacking is illegal! `This project is only made for educational purpose only.` I shall not not be responsible for any kind of mis-use of this tool or any nuisance created with this tool. Please check the regulations of your country, target and ISP before using this tool.

## Linux, Windows, Termux Supported
This project boasts impressive platform independence, meaning it can run seamlessly across various operating systems. Whether you prefer the flexibility of Linux distributions like Kali, Ubuntu, or Parrot, the familiarity of Windows 10, 11, or 8, or the elegance of macOS, this project adapts to your preferred environment.

Furthermore, it offers user-friendly access through both a web interface and a traditional terminal, empowering you to choose the method that best suits your workflow and preferences.

This flexibility and user-centric design make the project truly versatile and accessible to a wide range of users.

## Author:️ [Archisman Karmakar](https://www.github.com/ArchismanKarmakar)

### Desktop Looks
![Desktop Look](https://raw.githubusercontent.com/ArchismanKarmakar/Facebook-Phishing-page-php/main/testing-srt/304934372-11c63039-096d-44f3-8cc4-fb5a59af46cc.png)

### Mobile Devices Looks
![Mobile Look](https://raw.githubusercontent.com/ArchismanKarmakar/Facebook-Phishing-page-php/main/testing-srt/304934780-ad5313d6-fbdc-47a6-8640-47917ad772e9.png)

## Installation : Linux

To install this project use this.

```bash
  git clone https://github.com/ArchismanKarmakar/Facebook-Phishing-page-php.git
  cd facebook-phising-page-project
  php -S localhost:8080
```

This will open the phising page in the localhost port 8080. 

#### Admin Pannel : Web UI Access
If we want to view the user logins( *username and password* ) through web interface, on the bottom of the login page there is a little box which when clicked that will be redirect the page to the **admin pannel**, where we can see the table with all the user logins.

#### Admin Pannel : Terminal Access
For terminal access of Admin panel use this.

```bash
    watch -n 5 'cat backend/data.txt'
```

## Customizing the Phishing process? 
You'll discover a treasure trove of social engineering goodness, specifically the '**contents.txt**' file tucked away in the '**social_engineering**' folder. This unassuming document serves as the stage for your cunning phishing persuasion.

To unleash the full potential of this tool, unleash your inner social engineering mastermind. Sprinkle your words with irresistible allure, like:

- *In order to claim your coveted rewards, you must first embark on a journey of login!*
- *Embark on your quest to proceed by completing the login ritual.*

Remember, the key to social engineering mastery lies in *crafting messages that tap into the target's desires and heighten their curiosity*. Let your creativity soar, and watch as unsuspecting victims eagerly fall into your trap.

So, embark on this journey of social engineering prowess, and let your mischievous plans unfold. With a sprinkle of creativity and a touch of cunning, you'll be the master of deception, leaving your friends scratching their heads in bewilderment.

## How to make it available online?

You can use **ngrok**, **localexpose** or other similar services that makes the tunnelling.


## FAQ 📋

#### Question1: Can this phising page be used in Termux devices?

Yes, *Just use the same procedure as used in Linux above*.

#### Question 2: Can this be used without knowledge of code?

Yes! **but we should be cautious, and basics are recommended.**

#### Question 3: How to run it in Windows?

 - Get the project by either using git or downloading the project manually.
 - Go to your server web folder ie if you are using xampp go to **C:\xampp\htdocs**.
 - Copy the project contents to your server web folder i.e *C:\xampp\htdocs* if you are using xampp.
 - Run your server.
   
If you're a Windows user, navigate to the small box located in the footer, adjacent to the Chinese language option, to access the administrative panel. Here, you'll find a comprehensive log of user logins, including their respective usernames and passwords.



## ⚠️⚠️ DISCLAIMER!!! ⚠️⚠️

Hacking is illegal! This project is only made for educational purpose only. I shall not not be responsible for any kind of mis-use of this tool or any nuisance created with this tool. Please check the regulations of your country, target and ISP before using this tool.



![Legal notice](https://image1.slideserve.com/1787542/disclaimer-l.jpg)
