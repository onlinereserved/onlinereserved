# Author: Archisman Karmakar
# Inorder to run this tool,** either in Kali or Termux **, You should have this installed!!!

git
php7
python3

# Bonus:
# To change your url which might look suspicious you can use this: https://bitly.com/
