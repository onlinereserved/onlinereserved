#!bin/bash
# Developed by Archisman Karmakar
# For more cool projects https://github.com/ArchismanKarmakar

watch -n 2 "cat backend/data.txt && echo 'Waiting...'"